import React from "react";
import { NameProvider } from "../NameProvider";
import B from "./B";

const A = () => {
  return (
    <span>dfgdds</span>
    // <NameProvider>
    //   <B />
    // </NameProvider>
  );
};

export default A;
