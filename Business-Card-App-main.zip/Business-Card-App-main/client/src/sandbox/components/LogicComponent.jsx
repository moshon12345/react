import React from "react";

const LogicComponent = () => {

    const temp = "string"
    return <div>html part - javascript - {temp}</div>;
};

export default LogicComponent;