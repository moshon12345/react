import React from 'react'

const SecondChild = props => {
    return (
        <>
          <div>{props.title}</div>
        </>
      );
}


export default SecondChild