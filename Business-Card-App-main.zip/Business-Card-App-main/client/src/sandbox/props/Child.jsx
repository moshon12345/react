import React from "react";

const Child = ({ obj }) => {
  return (
    <>
      <div>{obj.first}</div>
    </>
  );
};

export default Child;
