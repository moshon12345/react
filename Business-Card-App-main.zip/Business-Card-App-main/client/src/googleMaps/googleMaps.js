// import { useMemo } from "react";
// import { GoogleMap, useLoadScript, Marker } from "@react-google-maps/api";

// export default function GoogleMaps() {
// //     const { isLoaded } = useLoadScript({
// //         googleMapsApiKey: "AIzaSyD0nW23C9R1LSpEf5S-WCe0KK2WizndYdw"
// //     });

// //     if (!isLoaded) return <div>Loaging....</div>;
// //     return <Map />;
// // }

// // function Map() {
// //     const center = useMemo(() => ({ lat: 44, lng: -80 }), [])

// //     return  (
// // <GoogleMap zoom={10} center={center} MapContainerClassName="map-container">
// // <Marker positon={center}/>
// // </GoogleMap>
// //     );
// }