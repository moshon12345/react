const SANDBOX_ROUTES = {
  ROOT: 'loops',
  LOOPS: 'loops',
  USE_STATE: 'use-state',
  HOOKS: 'hooks',
  USE_COUNTER: 'use-counter',
  USE_CALLBACK_BTN: 'use-callback-btn',
  USE_CONTEXT: 'use-context',
  FORMS: 'forms',
};

export default SANDBOX_ROUTES;
